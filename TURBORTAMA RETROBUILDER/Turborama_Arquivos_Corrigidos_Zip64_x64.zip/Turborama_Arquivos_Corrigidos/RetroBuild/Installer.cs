using System;
using System.IO;
using System.Security.Cryptography;

namespace RetroBuild
{
	internal class Installer
	{
		public static void CreateInstaller(BuilderOptions options)
		{
			string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
			string zipName = string.Concat(new string[] { "turborama-v", options.RetrobatVersion, "-", options.Branch, "-", options.Architecture, ".zip" });
			string zipPath = Path.Combine(baseDirectory, zipName);

			if (!File.Exists(zipPath))
			{
				Logger.Log("[INFO] zip not found, creating zip first.");
				try
				{
					Program.CreateZipFolderSharpZip(options);
				}
				catch (Exception ex)
				{
					Logger.Log("[ERROR] Exception creating ZIP: " + ex.Message);
				}
			}

			if (!File.Exists(zipPath))
			{
				Logger.Log("[ERROR] No .zip file found at: " + zipPath);
				return;
			}

			FileInfo zipInfo = new FileInfo(zipPath);
			Logger.LogInfo("Found zip file: " + zipPath);
			Logger.LogInfo("Zip size bytes: " + zipInfo.Length);

			string installerHostPath = Path.Combine(baseDirectory, "InstallerHost.exe");
			if (!File.Exists(installerHostPath))
			{
				Logger.Log("[ERROR] InstallerHost.exe not found at: " + installerHostPath);
				return;
			}

			Logger.LogInfo("Found InstallerHost.exe at: " + installerHostPath);

			try
			{
				string setupName = string.Concat(new string[] { "TurboRama-v", options.RetrobatVersion, "-", options.Branch, "-", options.Architecture, "-setup.exe" });
				string setupPath = Path.Combine(baseDirectory, setupName);
				string setupHashPath = setupPath + ".sha256.txt";

				if (File.Exists(setupPath))
				{
					File.SetAttributes(setupPath, FileAttributes.Normal);
					File.Delete(setupPath);
				}

				if (File.Exists(setupHashPath))
				{
					File.SetAttributes(setupHashPath, FileAttributes.Normal);
					File.Delete(setupHashPath);
				}

				using (FileStream output = new FileStream(setupPath, FileMode.CreateNew, FileAccess.Write, FileShare.None))
				{
					using (FileStream host = new FileStream(installerHostPath, FileMode.Open, FileAccess.Read, FileShare.Read))
					{
						host.CopyTo(output, 1024 * 1024);
					}

					using (FileStream zip = new FileStream(zipPath, FileMode.Open, FileAccess.Read, FileShare.Read))
					{
						long zipLength = zip.Length;
						zip.CopyTo(output, 1024 * 1024);

						// O InstallerHost le os ultimos 8 bytes do EXE como Int64.
						byte[] footer = BitConverter.GetBytes(zipLength);
						output.Write(footer, 0, footer.Length);
					}
				}

				using (FileStream read = File.OpenRead(setupPath))
				{
					using (SHA256 sha = SHA256.Create())
					{
						string hash = BitConverter.ToString(sha.ComputeHash(read)).Replace("-", "").ToLowerInvariant();
						File.WriteAllText(setupHashPath, hash);
					}
				}

				Logger.LogInfo("Created final installer executable: " + setupPath);
				Logger.LogInfo("Final installer size bytes: " + new FileInfo(setupPath).Length);
			}
			catch (Exception ex)
			{
				Logger.Log("[ERROR] Exception creating installer: " + ex.Message);
			}
		}
	}
}
