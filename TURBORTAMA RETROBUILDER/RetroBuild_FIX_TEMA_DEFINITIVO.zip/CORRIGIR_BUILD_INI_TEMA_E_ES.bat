@echo off
chcp 65001 >nul
setlocal

set "INI=%~dp0build.ini"

if not exist "%INI%" (
  echo [ERRO] build.ini nao encontrado na pasta:
  echo %~dp0
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ini = '%INI%';" ^
  "$txt = Get-Content -LiteralPath $ini -Raw;" ^
  "$theme = 'theme_path=https://github.com/luziellacerda/PC-RETRO-LZ-THEME-PC-NEW';" ^
  "$es = 'emulationstation_url=https://github.com/luziellacerda/TurboramaEmulationStation/releases/download/continuous-master/';" ^
  "if ($txt -match '(?m)^theme_path=') { $txt = $txt -replace '(?m)^theme_path=.*$', $theme } else { $txt = $txt.TrimEnd() + [Environment]::NewLine + $theme + [Environment]::NewLine };" ^
  "if ($txt -match '(?m)^emulationstation_url=') { $txt = $txt -replace '(?m)^emulationstation_url=.*$', $es } else { $txt = $txt.TrimEnd() + [Environment]::NewLine + $es + [Environment]::NewLine };" ^
  "Set-Content -LiteralPath $ini -Value $txt -Encoding UTF8;" ^
  "$carbon = Join-Path '%~dp0' 'build\emulationstation\.emulationstation\themes\es-theme-carbon';" ^
  "if (Test-Path $carbon) { Remove-Item -LiteralPath $carbon -Recurse -Force; Write-Host 'Pasta es-theme-carbon removida da build antiga.' }"

echo.
echo build.ini corrigido.
echo Tema correto:
echo https://github.com/luziellacerda/PC-RETRO-LZ-THEME-PC-NEW
echo.
echo EmulationStation correto:
echo https://github.com/luziellacerda/TurboramaEmulationStation/releases/download/continuous-master/EmulationStation-Win64.zip
echo.
pause
