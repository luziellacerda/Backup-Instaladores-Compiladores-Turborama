@echo off
chcp 65001 >nul
setlocal

set "INI=%~dp0build.ini"

if not exist "%INI%" (
  echo [ERRO] build.ini nao encontrado na pasta:
  echo %~dp0
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ini = '%INI%';" ^
  "$txt = Get-Content -LiteralPath $ini -Raw;" ^
  "$new = 'emulationstation_url=https://github.com/luziellacerda/TurboramaEmulationStation/releases/download/continuous-master/';" ^
  "$txt = $txt -replace 'emulationstation_url=https://github\.com/luziellacerda/EmulationStationsRetroBat2026/releases/download/continuous-master/?', $new;" ^
  "$txt = $txt -replace 'emulationstation_url=https://github\.com/luziellacerda/EmulationStationRetroBat2026/releases/download/continuous-master/?', $new;" ^
  "$txt = $txt -replace 'emulationstation_url=https://github\.com/luziellacerda/RetroBat2026/releases/download/continuous-master/?', $new;" ^
  "if ($txt -notmatch '(?m)^emulationstation_url=') { $txt = $txt.TrimEnd() + [Environment]::NewLine + $new + [Environment]::NewLine }" ^
  "$txt = $txt -replace '(?m)^theme_path=.*$', 'theme_path=https://github.com/luziellacerda/PC-RETRO-LZ-THEME-PC-NEW';" ^
  "Set-Content -LiteralPath $ini -Value $txt -Encoding UTF8;"

echo.
echo build.ini corrigido.
echo URL correta:
echo https://github.com/luziellacerda/TurboramaEmulationStation/releases/download/continuous-master/EmulationStation-Win64.zip
echo.
pause
