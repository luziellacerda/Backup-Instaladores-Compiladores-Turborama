@echo off
title TurboRama - Reparo Completo RetroBuild
color 0A
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Aplicar_REPARO_COMPLETO_RetroBuild.ps1"
pause
