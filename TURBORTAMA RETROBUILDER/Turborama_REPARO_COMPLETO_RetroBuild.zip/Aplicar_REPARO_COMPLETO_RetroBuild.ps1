param(
    [string]$ProjectRoot = "",
    [string]$TurboramaBinariesUrl = "https://github.com/luziellacerda/TurboramaBinarios/releases/download/continuous-master/turborama_binaries.7z",
    [string]$TurboramaEmulationStationUrl = "https://github.com/luziellacerda/TurboramaEmulationStation/releases/download/continuous-master/"
)

$ErrorActionPreference = "Stop"

function Ok($m) { Write-Host "[OK] $m" -ForegroundColor Green }
function Info($m) { Write-Host "[INFO] $m" -ForegroundColor Cyan }
function Warn($m) { Write-Host "[AVISO] $m" -ForegroundColor Yellow }
function Err($m) { Write-Host "[ERRO] $m" -ForegroundColor Red }

function SaveText($path, $text) {
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($path, $text, $utf8NoBom)
}

function BackupFile($path) {
    if (Test-Path -LiteralPath $path) {
        $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $bak = "$path.bak_turborama_reparo_$stamp"
        Copy-Item -LiteralPath $path -Destination $bak -Force
        return $bak
    }
    return $null
}

function FindFileByContent($root, $filter, $containsList) {
    $files = Get-ChildItem -LiteralPath $root -Recurse -Filter $filter -File -ErrorAction SilentlyContinue
    foreach ($f in $files) {
        try {
            if ($f.Length -gt 5MB) { continue }
            $c = [System.IO.File]::ReadAllText($f.FullName)
            $ok = $true
            foreach ($s in $containsList) {
                if (!$c.Contains($s)) {
                    $ok = $false
                    break
                }
            }
            if ($ok) {
                return $f
            }
        } catch {
        }
    }
    return $null
}

function Replace-IfPresent([string]$text, [string]$old, [string]$new) {
    if ($text.Contains($old)) {
        return $text.Replace($old, $new)
    }
    return $text
}

try {
    Clear-Host
    Write-Host ""
    Write-Host "======================================================="
    Write-Host " TURBORAMA - REPARO COMPLETO DO RETROBUILD"
    Write-Host "======================================================="
    Write-Host ""

    if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
        $ProjectRoot = Get-Location
    }

    $ProjectRoot = [System.IO.Path]::GetFullPath($ProjectRoot)

    Info "Pasta: $ProjectRoot"
    Info "Binarios: $TurboramaBinariesUrl"
    Info "EmulationStation: $TurboramaEmulationStationUrl"
    Write-Host ""

    $program = FindFileByContent $ProjectRoot "Program.cs" @("namespace RetroBuild", "GetPackages", "retrobat_binaries.7z")
    if ($program -eq $null) {
        throw "Nao encontrei Program.cs do RetroBuild. Extraia este reparo dentro da pasta da solution do RetroBuild."
    }

    $projectDir = $program.Directory.FullName
    $installer = Join-Path $projectDir "Installer.cs"
    $builderOptions = Join-Path $projectDir "BuilderOptions.cs"
    $assemblyInfo = Join-Path $projectDir "Properties\AssemblyInfo.cs"

    if (!(Test-Path -LiteralPath $installer)) {
        throw "Nao encontrei Installer.cs em: $projectDir"
    }
    if (!(Test-Path -LiteralPath $builderOptions)) {
        throw "Nao encontrei BuilderOptions.cs em: $projectDir"
    }

    Info "Projeto detectado: $projectDir"
    Info "Program.cs: $($program.FullName)"
    Info "Installer.cs: $installer"
    Info "BuilderOptions.cs: $builderOptions"
    if (Test-Path -LiteralPath $assemblyInfo) {
        Info "AssemblyInfo.cs: $assemblyInfo"
    }

    Write-Host ""
    Warn "Feche o Visual Studio antes de aplicar."
    Write-Host "Pressione ENTER para aplicar o reparo."
    Read-Host | Out-Null

    Get-Process devenv -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Get-Process MSBuild -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Get-Process VBCSCompiler -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Get-Process RetroBuild -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue

    # ---------------------------------------------------------------------
    # Program.cs
    # ---------------------------------------------------------------------
    BackupFile $program.FullName | Out-Null
    $p = [System.IO.File]::ReadAllText($program.FullName)

    $oldExact = @'
				string branch = options.Branch;
				string text5 = "retrobat_binaries.7z";
				Methods.DownloadAndExtractArchive_WebClient(options.RetrobatBinariesBaseUrl + branch + "/" + text5, text, options);
				Logger.LogInfo("retrobat binaries copied to " + text);
'@

    $newExact = @"
				string turboramaBinariesUrl = "$TurboramaBinariesUrl";
				Methods.DownloadAndExtractArchive_WebClient(turboramaBinariesUrl, text, options);
				Logger.LogInfo("turborama binaries copied to " + text);
"@

    if ($p.Contains($oldExact)) {
        $p = $p.Replace($oldExact, $newExact)
        Ok "Program.cs: chamada dos binarios trocada pelo bloco exato."
    }
    else {
        $pattern = 'string\s+branch\s*=\s*options\.Branch;\s*string\s+text5\s*=\s*"retrobat_binaries\.7z";\s*Methods\.DownloadAndExtractArchive_WebClient\(options\.RetrobatBinariesBaseUrl\s*\+\s*branch\s*\+\s*"/"\s*\+\s*text5,\s*text,\s*options\);\s*Logger\.LogInfo\("retrobat binaries copied to "\s*\+\s*text\);'
        if ($p -match $pattern) {
            $replacement = "string turboramaBinariesUrl = `"$TurboramaBinariesUrl`";`r`n`t`t`t`tMethods.DownloadAndExtractArchive_WebClient(turboramaBinariesUrl, text, options);`r`n`t`t`t`tLogger.LogInfo(`"turborama binaries copied to `" + text);"
            $p = [regex]::Replace($p, $pattern, $replacement, 1)
            Ok "Program.cs: chamada dos binarios trocada por regex."
        }
        elseif ($p.Contains($TurboramaBinariesUrl)) {
            Info "Program.cs: URL Turborama ja estava aplicada."
        }
        else {
            throw "Program.cs: nao consegui localizar a chamada retrobat_binaries.7z."
        }
    }

    # Branding seguro no console e nome do ZIP da opcao 2.
    $p = Replace-IfPresent $p "RetroBat Builder Menu" "TurboRama Builder Menu"
    $p = Replace-IfPresent $p "This executable is made to help download all the required software for RetroBat." "This executable is made to help download all the required software for TurboRama."
    $p = Replace-IfPresent $p ":: BUILDING RETROBAT TREE..." ":: BUILDING TURBORAMA TREE..."
    $p = Replace-IfPresent $p '"retrobat-v"' '"turborama-v"'
    $p = Replace-IfPresent $p "ZIP created at: " "ZIP created at: "

    # Nao alterar nomes internos:
    # retrobat_tree.lst, get_retrobat_binaries, Retrob atVersion, propriedades e listas.
    SaveText $program.FullName $p
    Ok "Program.cs reparado."

    # ---------------------------------------------------------------------
    # Installer.cs
    # ---------------------------------------------------------------------
    BackupFile $installer | Out-Null
    $i = [System.IO.File]::ReadAllText($installer)
    $i = Replace-IfPresent $i '"retrobat-v"' '"turborama-v"'
    $i = Replace-IfPresent $i '"RetroBat-v"' '"TurboRama-v"'
    # manter InstallerHost.exe
    SaveText $installer $i
    Ok "Installer.cs reparado."

    # ---------------------------------------------------------------------
    # BuilderOptions.cs
    # ---------------------------------------------------------------------
    BackupFile $builderOptions | Out-Null
    $b = [System.IO.File]::ReadAllText($builderOptions)

    # Mantem nomes internos Retrobat*, mas melhora defaults.
    $b = $b.Replace(
        'builderOptions.RetrobatBinariesBaseUrl = iniParser.Get(text, "retrobat_binaries_url", "http://www.retrobat.ovh/repo/tools/");',
        'builderOptions.RetrobatBinariesBaseUrl = iniParser.Get(text, "retrobat_binaries_url", "https://github.com/luziellacerda/TurboramaBinarios/releases/download/");'
    )
    $b = $b.Replace(
        'builderOptions.EmulationstationUrl = iniParser.Get(text, "emulationstation_url", "https://github.com/RetroBat-Official/emulationstation/releases/download/continuous-master/");',
        'builderOptions.EmulationstationUrl = iniParser.Get(text, "emulationstation_url", "https://github.com/luziellacerda/TurboramaEmulationStation/releases/download/continuous-master/");'
    )
    SaveText $builderOptions $b
    Ok "BuilderOptions.cs reparado."

    # ---------------------------------------------------------------------
    # AssemblyInfo.cs
    # ---------------------------------------------------------------------
    if (Test-Path -LiteralPath $assemblyInfo) {
        BackupFile $assemblyInfo | Out-Null
        $a = [System.IO.File]::ReadAllText($assemblyInfo)
        $a = Replace-IfPresent $a 'AssemblyTitle("RetroBuild")' 'AssemblyTitle("TurboRama Builder")'
        $a = Replace-IfPresent $a 'AssemblyDescription("Build tool for RetroBat")' 'AssemblyDescription("Build tool for TurboRama")'
        $a = Replace-IfPresent $a 'AssemblyCompany("The RetroBat team")' 'AssemblyCompany("LZ Games")'
        $a = Replace-IfPresent $a 'AssemblyProduct("RetroBuild")' 'AssemblyProduct("TurboRama Builder")'
        $a = Replace-IfPresent $a 'AssemblyCopyright("Copyright ©  2026")' 'AssemblyCopyright("Copyright © LZ Games 2026")'
        SaveText $assemblyInfo $a
        Ok "AssemblyInfo.cs reparado."
    }
    else {
        Warn "AssemblyInfo.cs nao encontrado. Pulando metadados."
    }

    # ---------------------------------------------------------------------
    # .csproj
    # ---------------------------------------------------------------------
    $csproj = FindFileByContent $ProjectRoot "*.csproj" @("<RootNamespace>RetroBuild</RootNamespace>")
    if ($csproj -ne $null) {
        BackupFile $csproj.FullName | Out-Null
        $c = [System.IO.File]::ReadAllText($csproj.FullName)

        # Mantem nome RetroBuild.exe. Apenas confere.
        if ($c -notmatch '<AssemblyName>RetroBuild</AssemblyName>') {
            Warn "csproj: AssemblyName nao esta RetroBuild. Nao alterei automaticamente."
        }
        else {
            Ok "csproj: AssemblyName preservado como RetroBuild."
        }

        if ($c -notmatch '<TargetFrameworkVersion>v4\.7\.2</TargetFrameworkVersion>') {
            Warn "csproj: TargetFrameworkVersion diferente de v4.7.2. Nao alterei."
        }

        SaveText $csproj.FullName $c
    }
    else {
        Warn "csproj do RetroBuild nao encontrado. Pulando."
    }

    # ---------------------------------------------------------------------
    # build.ini se existir na pasta do builder
    # ---------------------------------------------------------------------
    $buildIni = Join-Path $ProjectRoot "build.ini"
    if (!(Test-Path -LiteralPath $buildIni)) {
        $buildIni = Join-Path $projectDir "build.ini"
    }

    if (Test-Path -LiteralPath $buildIni) {
        BackupFile $buildIni | Out-Null
        $ini = [System.IO.File]::ReadAllText($buildIni)
        $ini = $ini.Replace("https://github.com/RetroBat-Official/emulationstation/releases/download/continuous-master/", $TurboramaEmulationStationUrl)
        $ini = $ini.Replace("http://www.retrobat.org/repo/win64/stable/retrobat_binaries.7z", $TurboramaBinariesUrl)
        $ini = $ini.Replace("http://www.retrobat.ovh/repo/win64/stable/retrobat_binaries.7z", $TurboramaBinariesUrl)
        SaveText $buildIni $ini
        Ok "build.ini reparado/conferido."
    }
    else {
        Warn "build.ini nao encontrado junto do projeto. Isso e normal se ele estiver so na pasta do exe final."
    }

    # Limpeza de build
    foreach ($folder in @(".vs", "bin", "obj")) {
        $target = Join-Path $projectDir $folder
        if (Test-Path $target) {
            Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction SilentlyContinue
            Ok "Removido: $target"
        }
    }

    Write-Host ""
    Write-Host "======================================================="
    Write-Host " REPARO CONCLUIDO"
    Write-Host "======================================================="
    Write-Host ""
    Write-Host "Agora abra a solution do RetroBuild e compile:"
    Write-Host "Release | Any CPU"
    Write-Host ""
    Write-Host "Resultado esperado:"
    Write-Host "bin\Release\RetroBuild.exe"
    Write-Host ""
    Write-Host "No log da opcao 1 deve aparecer:"
    Write-Host $TurboramaBinariesUrl
    Write-Host ""
    Write-Host "Opcao 2 deve gerar:"
    Write-Host "turborama-v[versao]-[branch]-[arquitetura].zip"
    Write-Host ""
    Write-Host "Opcao 3 deve gerar:"
    Write-Host "TurboRama-v[versao]-[branch]-[arquitetura]-setup.exe"
    Write-Host ""
}
catch {
    Write-Host ""
    Err $_.Exception.Message
    Write-Host ""
}
finally {
    Write-Host "Pressione ENTER para fechar."
    Read-Host | Out-Null
}
